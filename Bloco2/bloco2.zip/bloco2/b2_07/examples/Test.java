public class Test
{
   public int f() {}
   public void p() {}
}

